/*static char octardate[] = "Sun Aug 10 11:25:14 CEST 2008";*/
