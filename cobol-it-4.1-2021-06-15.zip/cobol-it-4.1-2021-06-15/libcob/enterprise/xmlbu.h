/*CIT_BEGIN_ENTERPRISE*/
#ifndef LMXU
#define LMXU 1

/*
  Here, put user-defined macro definitions that can possibly
  override the definition found in xmlb.h
*/

#define BUFFER_SIZE (64*1024)
#define XMLB_ALIGN_STEP 8

/*#define XMLB_NO_TAG_TABLE*/
/*#define XMLB_STRDUP_NO_STRICT*/

#endif

