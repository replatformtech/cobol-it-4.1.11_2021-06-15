COBOL_FLAGS=$* ${COBOL_FLAGS}
export COBOL_FLAGS
sh run-O
sh syntax-O
sh data-rep-O
