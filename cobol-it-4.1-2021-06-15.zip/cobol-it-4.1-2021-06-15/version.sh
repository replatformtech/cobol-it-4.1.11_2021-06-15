echo `cat version`-`cat distribution`-`cat model`
